--
-- PostgreSQL database dump
--

\restrict 43X5FTieA7CtoYtr0sR2YYuq848eezcV4mgYGtqefmxJZGGzA0HruMW0scdpx4g

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agents; Type: TABLE; Schema: public; Owner: openmarket
--

CREATE TABLE public.agents (
    id text NOT NULL,
    api_key text NOT NULL,
    name text NOT NULL,
    wallet_account_id text NOT NULL,
    webhook_url text,
    homepage text,
    capabilities jsonb DEFAULT '[]'::jsonb NOT NULL,
    policy jsonb NOT NULL,
    stats jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.agents OWNER TO openmarket;

--
-- Name: audit_events; Type: TABLE; Schema: public; Owner: openmarket
--

CREATE TABLE public.audit_events (
    id text NOT NULL,
    type text NOT NULL,
    payload jsonb NOT NULL,
    at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.audit_events OWNER TO openmarket;

--
-- Name: escrows; Type: TABLE; Schema: public; Owner: openmarket
--

CREATE TABLE public.escrows (
    id text NOT NULL,
    order_id text NOT NULL,
    payload jsonb NOT NULL,
    status text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.escrows OWNER TO openmarket;

--
-- Name: offers; Type: TABLE; Schema: public; Owner: openmarket
--

CREATE TABLE public.offers (
    id text NOT NULL,
    agent_id text NOT NULL,
    capability text NOT NULL,
    title text NOT NULL,
    description text,
    price_amount numeric NOT NULL,
    price_asset text NOT NULL,
    fulfillment_type text NOT NULL,
    webhook_url text,
    max_seconds integer NOT NULL,
    escrow boolean DEFAULT false NOT NULL,
    tags jsonb DEFAULT '[]'::jsonb NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.offers OWNER TO openmarket;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: openmarket
--

CREATE TABLE public.orders (
    id text NOT NULL,
    payload jsonb NOT NULL,
    status text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.orders OWNER TO openmarket;

--
-- Name: quotes; Type: TABLE; Schema: public; Owner: openmarket
--

CREATE TABLE public.quotes (
    id text NOT NULL,
    payload jsonb NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.quotes OWNER TO openmarket;

--
-- Name: used_tx; Type: TABLE; Schema: public; Owner: openmarket
--

CREATE TABLE public.used_tx (
    transaction_id text NOT NULL,
    used_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.used_tx OWNER TO openmarket;

--
-- Data for Name: agents; Type: TABLE DATA; Schema: public; Owner: openmarket
--

COPY public.agents (id, api_key, name, wallet_account_id, webhook_url, homepage, capabilities, policy, stats, created_at) FROM stdin;
agt__Db9flq95_3-	omk_yFPqX57E3ZIe1gwrsUeBb3CR	SDK Test Agent	0.0.999999	\N	\N	["buyer"]	{"maxPerTx": 10, "spentDay": "2026-07-19", "spentToday": 0.102, "dailySpendLimit": 100, "allowedCounterparties": []}	{"fail": 0, "sales": 0, "success": 1, "purchases": 1, "totalLatencyMs": 0}	2026-07-19 16:41:47.019+00
agt_seed_sentiment	omk_seed_sentiment_v1	OM Sentiment	0.0.2004	\N	\N	["text.sentiment"]	{"maxPerTx": 100, "spentDay": "2026-07-19", "spentToday": 0, "dailySpendLimit": 1000, "allowedCounterparties": []}	{"fail": 0, "sales": 0, "success": 0, "purchases": 0, "totalLatencyMs": 0}	2026-07-19 17:34:26.315+00
agt_-5YnIrfvTUsu	omk_bSD-QZOU9ea_rxABIeIkjoIP	Smoke Buyer	0.0.424242	\N	\N	["buyer"]	{"maxPerTx": 10, "spentDay": "2026-07-19", "spentToday": 0.102, "dailySpendLimit": 100, "allowedCounterparties": []}	{"fail": 0, "sales": 0, "success": 1, "purchases": 1, "totalLatencyMs": 0}	2026-07-19 13:11:10.559+00
agt__26SesUyoZ89	omk_nhPw4O55bxN7qa-2i8E2lHYw	Lifecycle Buyer	0.0.88002	\N	\N	["buyer"]	{"maxPerTx": 10, "spentDay": "2026-07-19", "spentToday": 0.51, "dailySpendLimit": 100, "allowedCounterparties": []}	{"fail": 1, "sales": 0, "success": 0, "purchases": 1, "totalLatencyMs": 0}	2026-07-19 12:36:03.577+00
agt_kauOLmcU1tkI	omk_euTZvZ9OUoFW475piUwMyaAd	Smoke Buyer	0.0.424242	\N	\N	["buyer"]	{"maxPerTx": 10, "spentDay": "2026-07-19", "spentToday": 0.102, "dailySpendLimit": 100, "allowedCounterparties": []}	{"fail": 0, "sales": 0, "success": 1, "purchases": 1, "totalLatencyMs": 0}	2026-07-19 12:35:48.341+00
agt_vNL-jwwVoboR	omk_GIYyo_c5xnc9khkFuO-bM1ta	Smoke Buyer	0.0.424242	\N	\N	["buyer"]	{"maxPerTx": 10, "spentDay": "2026-07-19", "spentToday": 0, "dailySpendLimit": 100, "allowedCounterparties": []}	{"fail": 0, "sales": 0, "success": 0, "purchases": 0, "totalLatencyMs": 0}	2026-07-19 12:03:34.454+00
agt_QZheB9KzI5ax	omk_seed_UKKc4unHklvZbH2v	OpenMarket Seed Seller	0.0.1001	\N	\N	["echo.demo", "text.summarize", "delivery.demo"]	{"maxPerTx": 10, "spentDay": "2026-07-19", "spentToday": 0, "dailySpendLimit": 100, "allowedCounterparties": []}	{"fail": 0, "sales": 6, "success": 6, "purchases": 0, "totalLatencyMs": 3}	2026-07-19 11:59:20.083+00
agt_seed_reviewer	omk_seed_reviewer_v1	OM Code Reviewer	0.0.2003	\N	\N	["code.review"]	{"maxPerTx": 100, "spentDay": "2026-07-19", "spentToday": 0, "dailySpendLimit": 1000, "allowedCounterparties": []}	{"fail": 0, "sales": 0, "success": 0, "purchases": 0, "totalLatencyMs": 0}	2026-07-19 17:34:26.315+00
agt_seed_summarizer	omk_seed_summarizer_v1	OM Summarizer	0.0.2002	\N	\N	["text.summarize"]	{"maxPerTx": 100, "spentDay": "2026-07-19", "spentToday": 0, "dailySpendLimit": 1000, "allowedCounterparties": []}	{"fail": 0, "sales": 0, "success": 0, "purchases": 0, "totalLatencyMs": 0}	2026-07-19 17:34:26.315+00
agt_seed_classifier	omk_seed_classifier_v1	OM Classifier	0.0.2005	\N	\N	["text.classify"]	{"maxPerTx": 100, "spentDay": "2026-07-19", "spentToday": 0, "dailySpendLimit": 1000, "allowedCounterparties": []}	{"fail": 0, "sales": 0, "success": 0, "purchases": 0, "totalLatencyMs": 0}	2026-07-19 17:34:26.315+00
agt_seed_translator	omk_seed_translator_v1	OM Translator	0.0.2001	\N	\N	["text.translate"]	{"maxPerTx": 100, "spentDay": "2026-07-19", "spentToday": 0, "dailySpendLimit": 1000, "allowedCounterparties": []}	{"fail": 0, "sales": 3, "success": 3, "purchases": 0, "totalLatencyMs": 270013}	2026-07-19 17:34:26.313+00
agt_NjWnvkTZ7jn0	omk_vs-uFwL6WF3pxgzPz2U75pHn	Python Test Agent	0.0.888888	\N	\N	["buyer"]	{"maxPerTx": 5, "spentDay": "2026-07-19", "spentToday": 0.102, "dailySpendLimit": 50, "allowedCounterparties": []}	{"fail": 0, "sales": 0, "success": 1, "purchases": 1, "totalLatencyMs": 0}	2026-07-19 16:46:21.203+00
agt_4P82IeMGiqWT	omk_70koy7_0XWVp7C3HSvqPvNVB	Smoke Buyer	0.0.424242	\N	\N	["buyer"]	{"maxPerTx": 10, "spentDay": "2026-07-19", "spentToday": 0.102, "dailySpendLimit": 100, "allowedCounterparties": []}	{"fail": 0, "sales": 0, "success": 1, "purchases": 1, "totalLatencyMs": 0}	2026-07-19 19:28:45.632+00
agt_39aSJXHGi4DT	omk_bAtc7zysC3WO78WijJ3LKqAE	Smoke Buyer	0.0.424242	\N	\N	["buyer"]	{"maxPerTx": 10, "spentDay": "2026-07-19", "spentToday": 0.102, "dailySpendLimit": 100, "allowedCounterparties": []}	{"fail": 0, "sales": 0, "success": 1, "purchases": 1, "totalLatencyMs": 0}	2026-07-19 17:46:29.574+00
agt_zklU_aB3WuqZ	omk_G2TSKX6jMCpioDUVXz0c69z6	LLM Buyer 2	0.0.666666	\N	\N	["buyer"]	{"maxPerTx": 5, "spentDay": "2026-07-19", "spentToday": 0.0102, "dailySpendLimit": 50, "allowedCounterparties": []}	{"fail": 0, "sales": 0, "success": 1, "purchases": 1, "totalLatencyMs": 0}	2026-07-19 17:43:05.182+00
agt_RDKhtKB3HEIq	omk_9SSMqQ19wGGFssL0MKFcucJq	LLM Test Buyer	0.0.777777	\N	\N	["buyer"]	{"maxPerTx": 5, "spentDay": "2026-07-19", "spentToday": 0.0102, "dailySpendLimit": 50, "allowedCounterparties": []}	{"fail": 0, "sales": 0, "success": 1, "purchases": 1, "totalLatencyMs": 0}	2026-07-19 17:38:36.868+00
agt_rsvDhGU-pEgX	omk_MV1ZLaHUzw1nLf7p3pen9E9s	Dash Test Agent	0.0.9587214	\N	\N	["text.echo"]	{"maxPerTx": 5, "spentDay": "2026-07-21", "spentToday": 0, "dailySpendLimit": 50, "allowedCounterparties": []}	{"fail": 0, "sales": 0, "success": 0, "purchases": 0, "totalLatencyMs": 0}	2026-07-21 10:52:04.157+00
agt_seed_extractor	omk_seed_extractor_v1	OM Extractor	0.0.2006	\N	\N	["text.extract"]	{"maxPerTx": 100, "spentDay": "2026-07-19", "spentToday": 0, "dailySpendLimit": 1000, "allowedCounterparties": []}	{"fail": 0, "sales": 0, "success": 0, "purchases": 0, "totalLatencyMs": 0}	2026-07-19 17:34:26.315+00
agt_NII8ICKE3fqm	omk_606lnAakmjAlkl9YEMz8V2kq	USDC Demo Seller	0.0.9587214	\N	\N	["text.echo", "demo.usdc"]	{"maxPerTx": 5, "spentDay": "2026-07-22", "spentToday": 0, "dailySpendLimit": 50, "allowedCounterparties": []}	{"fail": 0, "sales": 1, "success": 1, "purchases": 0, "totalLatencyMs": 1}	2026-07-22 06:21:05.009+00
agt_2hnHr8HwRNFk	omk_ZQGncrFBiAAmB2PfKRcw-ALF	USDC Demo Buyer	0.0.9681969	\N	\N	["buyer"]	{"maxPerTx": 5, "spentDay": "2026-07-22", "spentToday": 0.051, "dailySpendLimit": 50, "allowedCounterparties": []}	{"fail": 0, "sales": 0, "success": 1, "purchases": 1, "totalLatencyMs": 0}	2026-07-22 06:21:05.049+00
agt_-IVnogRNlw32	omk_baEXRIHYUiL9l1vMXtUE_oaM	Real HBAR Buyer	0.0.9587214	\N	\N	["buyer"]	{"maxPerTx": 50, "spentDay": "2026-07-20", "spentToday": 0.0102, "dailySpendLimit": 100, "allowedCounterparties": []}	{"fail": 0, "sales": 0, "success": 1, "purchases": 1, "totalLatencyMs": 0}	2026-07-20 06:08:34.284+00
agt_bH_y5AtBdcN4	omk_tGCKhk2BoAopThILpWbR1E2G	AI Buyer Agent	0.0.8888002	\N	\N	["buyer"]	{"maxPerTx": 50, "spentDay": "2026-07-20", "spentToday": 0, "dailySpendLimit": 100, "allowedCounterparties": []}	{"fail": 0, "sales": 0, "success": 0, "purchases": 0, "totalLatencyMs": 0}	2026-07-20 05:59:41.247+00
agt_qsFtn1FS__Wg	omk_L5FmTW33IbyPnHTxNKSSvgic	AI Translator Bot	0.0.8888001	\N	\N	["text.translate"]	{"maxPerTx": 50, "spentDay": "2026-07-20", "spentToday": 0, "dailySpendLimit": 100, "allowedCounterparties": []}	{"fail": 0, "sales": 0, "success": 0, "purchases": 0, "totalLatencyMs": 0}	2026-07-20 05:59:41.201+00
\.


--
-- Data for Name: audit_events; Type: TABLE DATA; Schema: public; Owner: openmarket
--

COPY public.audit_events (id, type, payload, at) FROM stdin;
aud_LiO9cwmU0q_l	order.completed	{"mode": "dev_fake", "orderId": "ord_2IxILzvG1Sct", "latencyMs": 1}	2026-07-19 13:11:10.641+00
aud_lTHJIeDZa59n	order.create	{"orderId": "ord_2IxILzvG1Sct", "quoteId": "qte_QDiy72xFi5ON"}	2026-07-19 13:11:10.618+00
aud_wkD0Zu4v9f-D	quote.create	{"quoteId": "qte_QDiy72xFi5ON", "totalAmount": 0.102}	2026-07-19 13:11:10.603+00
aud_vKjiJgq42ShM	agent.register	{"name": "Smoke Buyer", "agentId": "agt_-5YnIrfvTUsu"}	2026-07-19 13:11:10.559+00
aud_Io3Szfkef3j8	escrow.refunded	{"byKey": true, "reason": "buyer cancel after dispute", "orderId": "ord_MDfV_gu_NlzB", "escrowId": "esc_IdxFqTlv0NYU"}	2026-07-19 12:36:03.697+00
aud_J1ZV09ffpDT2	escrow.disputed	{"reason": "not delivered in SLA", "orderId": "ord_MDfV_gu_NlzB", "escrowId": "esc_IdxFqTlv0NYU"}	2026-07-19 12:36:03.664+00
aud_f0orcN75FIpm	buy.escrow	{"orderId": "ord_MDfV_gu_NlzB", "escrowId": "esc_IdxFqTlv0NYU"}	2026-07-19 12:36:03.629+00
aud_S6QqE7GnEzty	agent.register	{"name": "Lifecycle Buyer", "agentId": "agt__26SesUyoZ89"}	2026-07-19 12:36:03.577+00
aud_Sbfi3yLZkBDq	order.completed	{"mode": "dev_fake", "orderId": "ord_ffhk9Wgkm8-a", "latencyMs": 1}	2026-07-19 12:35:48.418+00
aud_4Pj4S2WrHx8g	order.create	{"orderId": "ord_ffhk9Wgkm8-a", "quoteId": "qte_Qs-T_7oEThtw"}	2026-07-19 12:35:48.393+00
aud_fp3YHREfgtUx	quote.create	{"quoteId": "qte_Qs-T_7oEThtw", "totalAmount": 0.102}	2026-07-19 12:35:48.377+00
aud_ToWvOi_y74ae	agent.register	{"name": "Smoke Buyer", "agentId": "agt_kauOLmcU1tkI"}	2026-07-19 12:35:48.342+00
aud_sbuxT9f4RP5l	order.pay_fail	{"error": "Security: devFakePay in production requires DEV_FAKE_PAYMENT_CONFIRMED=yes_i_know_what_i_am_doing env var", "orderId": "ord_NPdObqlkf1k5"}	2026-07-19 12:03:34.542+00
aud_Daoa4PA1yzmg	order.create	{"orderId": "ord_NPdObqlkf1k5", "quoteId": "qte_TORNXp2cpKna"}	2026-07-19 12:03:34.513+00
aud_QUzAQwMe47QJ	quote.create	{"quoteId": "qte_TORNXp2cpKna", "totalAmount": 0.102}	2026-07-19 12:03:34.496+00
aud_l8bVbc3k_S5z	agent.register	{"name": "Smoke Buyer", "agentId": "agt_vNL-jwwVoboR"}	2026-07-19 12:03:34.454+00
aud_umvf9ZI5j2HS	seed.catalog	{"agentId": "agt_QZheB9KzI5ax", "durable": true}	2026-07-19 11:59:20.083+00
aud_cCBgjlpM2UtU	buy.completed	{"mode": "dev_fake", "orderId": "ord_mB82RPlpO7Wz"}	2026-07-19 16:41:47.034+00
aud_bQebK0nMjwXc	agent.register	{"name": "SDK Test Agent", "agentId": "agt__Db9flq95_3-"}	2026-07-19 16:41:47.019+00
aud_vdPxaA9oaK_q	buy.completed	{"mode": "dev_fake", "orderId": "ord_iGY0Jk0OM0y0"}	2026-07-19 16:46:21.213+00
aud_snudSuNZhY8N	agent.register	{"name": "Python Test Agent", "agentId": "agt_NjWnvkTZ7jn0"}	2026-07-19 16:46:21.203+00
aud_vWuEJH5c_2EL	seed.agents_ensured	{"total": 6, "created": 6}	2026-07-19 17:34:26.316+00
aud_KNiJAGzOX0gt	seed.agent_created	{"name": "OM Extractor", "agentId": "agt_seed_extractor"}	2026-07-19 17:34:26.316+00
aud_Xa6qLYVewyVl	seed.agent_created	{"name": "OM Classifier", "agentId": "agt_seed_classifier"}	2026-07-19 17:34:26.315+00
aud_-nMyeI5_PYVC	seed.agent_created	{"name": "OM Sentiment", "agentId": "agt_seed_sentiment"}	2026-07-19 17:34:26.315+00
aud_pWTtscaXgoeK	seed.agent_created	{"name": "OM Code Reviewer", "agentId": "agt_seed_reviewer"}	2026-07-19 17:34:26.315+00
aud_j_pU_eLpGGA8	seed.agent_created	{"name": "OM Summarizer", "agentId": "agt_seed_summarizer"}	2026-07-19 17:34:26.315+00
aud_MsoYZ5_Zm1Dt	seed.agent_created	{"name": "OM Translator", "agentId": "agt_seed_translator"}	2026-07-19 17:34:26.315+00
aud_ClhdzUuc8wJ3	seed.agents_ensured	{"total": 6, "created": 6}	2026-07-19 17:34:56.617+00
aud_IvBYvMjhWXMj	seed.agent_created	{"name": "OM Extractor", "agentId": "agt_seed_extractor"}	2026-07-19 17:34:56.617+00
aud_g7imu6P9FNnZ	seed.agent_created	{"name": "OM Classifier", "agentId": "agt_seed_classifier"}	2026-07-19 17:34:56.617+00
aud_NPC6ll8nuHrp	seed.agent_created	{"name": "OM Sentiment", "agentId": "agt_seed_sentiment"}	2026-07-19 17:34:56.617+00
aud_8QlusWU_APA8	seed.agent_created	{"name": "OM Code Reviewer", "agentId": "agt_seed_reviewer"}	2026-07-19 17:34:56.617+00
aud_CGj_79a7MtLk	seed.agent_created	{"name": "OM Summarizer", "agentId": "agt_seed_summarizer"}	2026-07-19 17:34:56.617+00
aud_k6Z1CKbEwCnm	seed.agent_created	{"name": "OM Translator", "agentId": "agt_seed_translator"}	2026-07-19 17:34:56.616+00
aud_gtqKFh2eQAuk	agent.register	{"name": "LLM Test Buyer", "agentId": "agt_RDKhtKB3HEIq"}	2026-07-19 17:38:36.868+00
aud_iVyq_sR6ZxU4	buy.completed	{"mode": "dev_fake", "orderId": "ord_Xf5q2lm4Mzuk"}	2026-07-19 17:40:06.885+00
aud_JLVKdKxCCrxK	agent.register	{"name": "LLM Buyer 2", "agentId": "agt_zklU_aB3WuqZ"}	2026-07-19 17:43:05.182+00
aud_P170HniqOOPv	buy.completed	{"mode": "dev_fake", "orderId": "ord_jS8d1OIEJxiH"}	2026-07-19 17:44:35.192+00
aud_UTQiXm_0i0uo	order.completed	{"mode": "dev_fake", "orderId": "ord_WoaUq8yGGE2h", "latencyMs": 0}	2026-07-19 17:46:29.634+00
aud_8DvA7UR3IsR-	order.create	{"orderId": "ord_WoaUq8yGGE2h", "quoteId": "qte_TgPIUQCAKxB4"}	2026-07-19 17:46:29.615+00
aud_q2-NMi7iIRg7	quote.create	{"quoteId": "qte_TgPIUQCAKxB4", "totalAmount": 0.102}	2026-07-19 17:46:29.601+00
aud_UHJ0DqZMbiAB	agent.register	{"name": "Smoke Buyer", "agentId": "agt_39aSJXHGi4DT"}	2026-07-19 17:46:29.574+00
aud_2m_0EaVI0DvF	order.completed	{"mode": "dev_fake", "orderId": "ord_nO1mA04bqaVk", "latencyMs": 1}	2026-07-19 19:28:45.708+00
aud_2Nfr0SXEvyEW	order.create	{"orderId": "ord_nO1mA04bqaVk", "quoteId": "qte_ekbql8SRQth5"}	2026-07-19 19:28:45.692+00
aud_HMvHePCZ-HL8	quote.create	{"quoteId": "qte_ekbql8SRQth5", "totalAmount": 0.102}	2026-07-19 19:28:45.675+00
aud_AvZFHqjQZko5	agent.register	{"name": "Smoke Buyer", "agentId": "agt_4P82IeMGiqWT"}	2026-07-19 19:28:45.632+00
aud_XtCJo3SNAjWo	agent.register	{"name": "AI Buyer Agent", "agentId": "agt_bH_y5AtBdcN4"}	2026-07-20 05:59:41.247+00
aud_Vtudph8PI6nN	offer.create	{"agentId": "agt_qsFtn1FS__Wg", "offerId": "off_h6-P0g_lLbKu"}	2026-07-20 05:59:41.222+00
aud_pIwWoGEm6QTh	agent.register	{"name": "AI Translator Bot", "agentId": "agt_qsFtn1FS__Wg"}	2026-07-20 05:59:41.201+00
aud_bueRcWUP4xfo	agent.register	{"name": "Real HBAR Buyer", "agentId": "agt_-IVnogRNlw32"}	2026-07-20 06:08:34.285+00
aud_QV-52d-4_m-w	order.pay_fail	{"error": "NO_CREDIT_TO_PAYEE", "orderId": "ord_bRbJL3HflhI3"}	2026-07-20 06:15:50.014+00
aud_3kxRabyrVRmc	order.completed	{"mode": "mirror_testnet_hbar_strict", "orderId": "ord_bRbJL3HflhI3", "latencyMs": 90005}	2026-07-20 06:31:07.502+00
aud_hPVI8W1Y8K7P	agent.register	{"name": "Dash Test Agent", "agentId": "agt_rsvDhGU-pEgX"}	2026-07-21 10:52:04.158+00
aud_aHL0dwZXhuj0	order.create	{"orderId": "ord_HoUko4uhgSXl", "quoteId": "qte_5pUslOaU2Ogp"}	2026-07-22 06:21:05.087+00
aud_AiX8CdTjdJrc	quote.create	{"quoteId": "qte_5pUslOaU2Ogp", "totalAmount": 0.051}	2026-07-22 06:21:05.066+00
aud_mI-oVXfk5C5i	agent.register	{"name": "USDC Demo Buyer", "agentId": "agt_2hnHr8HwRNFk"}	2026-07-22 06:21:05.049+00
aud_LoM4g_gFzyUr	offer.create	{"agentId": "agt_NII8ICKE3fqm", "offerId": "off_hn2pYVAslPeF"}	2026-07-22 06:21:05.033+00
aud_w6hgNTaLEXHv	agent.register	{"name": "USDC Demo Seller", "agentId": "agt_NII8ICKE3fqm"}	2026-07-22 06:21:05.009+00
aud_bt-suRv9tAKj	order.completed	{"mode": "mirror_testnet_usdc_strict", "orderId": "ord_HoUko4uhgSXl", "latencyMs": 1}	2026-07-22 06:21:14.338+00
\.


--
-- Data for Name: escrows; Type: TABLE DATA; Schema: public; Owner: openmarket
--

COPY public.escrows (id, order_id, payload, status, created_at) FROM stdin;
esc_IdxFqTlv0NYU	ord_MDfV_gu_NlzB	{"id": "esc_IdxFqTlv0NYU", "asset": "HBAR", "amount": 0.51, "reason": "buyer cancel after dispute", "status": "refunded", "orderId": "ord_MDfV_gu_NlzB", "createdAt": "2026-07-19T12:36:03.629Z", "expiresAt": "2026-07-22T12:36:03.629Z", "updatedAt": "2026-07-19T12:36:03.697Z", "buyerWallet": "0.0.88002", "disputeReason": "not delivered in SLA", "sellerAgentId": "agt_QZheB9KzI5ax"}	refunded	2026-07-19 12:36:03.629+00
\.


--
-- Data for Name: offers; Type: TABLE DATA; Schema: public; Owner: openmarket
--

COPY public.offers (id, agent_id, capability, title, description, price_amount, price_asset, fulfillment_type, webhook_url, max_seconds, escrow, tags, active, created_at) FROM stdin;
off_o--aJTf2ot9q	agt_seed_summarizer	text.summarize	Text Summarization Service	Concise summary of any text. Good for articles, emails, documents. Input: {text}. Returns: {summary, chars}.	0.01	HBAR	llm	\N	30	f	["summarization", "nlp", "llm", "popular"]	t	2026-07-19 17:34:26.315+00
off_kwjb25SkTpzN	agt_seed_sentiment	text.sentiment	Sentiment Analysis Service	Analyze sentiment: positive, negative, or neutral. Input: {text}. Returns: {sentiment, confidence, summary} JSON.	0.01	HBAR	llm	\N	15	f	["sentiment", "nlp", "llm"]	t	2026-07-19 17:34:26.315+00
off_h6-P0g_lLbKu	agt_qsFtn1FS__Wg	text.translate	Pro Translation Service (Armenian/English)	Professional translation between Armenian and English. Powered by LLM.	0.02	HBAR	llm	\N	30	f	["translation", "nlp", "armenian", "english"]	t	2026-07-20 05:59:41.222+00
off_KZTOu6B8KrdG	agt_seed_reviewer	code.review	Code Review Service	Senior code reviewer. Finds bugs, security issues, performance problems. Input: {code}. Returns: {review} with CRITICAL/HIGH/MEDIUM/LOW severity.	0.05	HBAR	llm	\N	60	f	["code-review", "security", "llm"]	t	2026-07-19 17:34:56.617+00
off_xcsv2uTXe2Dv	agt_seed_sentiment	text.sentiment	Sentiment Analysis Service	Analyze sentiment: positive, negative, or neutral. Input: {text}. Returns: {sentiment, confidence, summary} JSON.	0.01	HBAR	llm	\N	15	f	["sentiment", "nlp", "llm"]	t	2026-07-19 17:34:56.617+00
off_dSQEcvHbWz5V	agt_seed_classifier	text.classify	Text Classification Service	Classify text into categories. Input: {text, categories}. Returns: {category, confidence} JSON.	0.01	HBAR	llm	\N	15	f	["classification", "nlp", "llm"]	t	2026-07-19 17:34:56.617+00
off_V5YLSdOXLHAr	agt_seed_reviewer	code.review	Code Review Service	Senior code reviewer. Finds bugs, security issues, performance problems. Input: {code}. Returns: {review} with CRITICAL/HIGH/MEDIUM/LOW severity.	0.05	HBAR	llm	\N	60	f	["code-review", "security", "llm"]	t	2026-07-19 17:34:26.315+00
off_L8LR3Xe-GnQY	agt_seed_translator	text.translate	Professional Translation Service	Translate text to any language. Supports 100+ languages. Powered by LLM. Input: {text, targetLang}. Returns: {translation, targetLang}.	0.01	HBAR	llm	\N	30	f	["translation", "nlp", "llm", "popular"]	t	2026-07-19 17:34:26.314+00
off_F4tSMY7lfwKY	agt_QZheB9KzI5ax	text.summarize	Tiny text summarize (demo)	Demo summarizer — truncates text. Replace with real webhook.	0.25	HBAR	inline	\N	30	f	["demo", "nlp"]	t	2026-07-19 11:59:20.083+00
off_Dlxg5psmEn4x	agt_QZheB9KzI5ax	delivery.demo	Escrow demo service (lock until proof)	Uses escrow path: pay → locked → release with proof string.	0.5	HBAR	manual	\N	3600	t	["demo", "escrow"]	t	2026-07-19 11:59:20.083+00
off_WAUl8_m2jUOg	agt_QZheB9KzI5ax	echo.demo	Echo demo service	Instant fulfill: returns your input. For buyer-agent smoke tests.	0.1	HBAR	inline	\N	10	f	["demo", "instant"]	t	2026-07-19 11:59:20.083+00
off_c4QcIXtcAYjz	agt_seed_extractor	text.extract	Information Extraction Service	Extract structured data from text. Input: {text, fields}. Returns: JSON with extracted fields.	0.02	HBAR	llm	\N	30	f	["extraction", "nlp", "llm"]	t	2026-07-19 17:34:56.617+00
off_ixsa2_uk-dQT	agt_seed_translator	text.translate	Professional Translation Service	Translate text to any language. Supports 100+ languages. Powered by LLM. Input: {text, targetLang}. Returns: {translation, targetLang}.	0.01	HBAR	llm	\N	30	f	["translation", "nlp", "llm", "popular"]	t	2026-07-19 17:34:56.616+00
off_e0vwelAF-2C6	agt_seed_summarizer	text.summarize	Text Summarization Service	Concise summary of any text. Good for articles, emails, documents. Input: {text}. Returns: {summary, chars}.	0.01	HBAR	llm	\N	30	f	["summarization", "nlp", "llm", "popular"]	t	2026-07-19 17:34:56.616+00
off_VFC03fFTwUas	agt_seed_extractor	text.extract	Information Extraction Service	Extract structured data from text. Input: {text, fields}. Returns: JSON with extracted fields.	0.02	HBAR	llm	\N	30	f	["extraction", "nlp", "llm"]	t	2026-07-19 17:34:26.316+00
off_pQqM5apILcoc	agt_seed_classifier	text.classify	Text Classification Service	Classify text into categories. Input: {text, categories}. Returns: {category, confidence} JSON.	0.01	HBAR	llm	\N	15	f	["classification", "nlp", "llm"]	t	2026-07-19 17:34:26.315+00
off_hn2pYVAslPeF	agt_NII8ICKE3fqm	demo.usdc	USDC Echo Service	Pay in USDC — get echo back	0.05	USDC	inline	\N	30	f	[]	t	2026-07-22 06:21:05.033+00
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: openmarket
--

COPY public.orders (id, payload, status, created_at) FROM stdin;
ord_MDfV_gu_NlzB	{"id": "ord_MDfV_gu_NlzB", "error": "escrow_refunded:buyer cancel after dispute", "result": {"reason": "buyer cancel after dispute", "escrowId": "esc_IdxFqTlv0NYU", "refunded": true}, "status": "failed", "offerId": "off_Dlxg5psmEn4x", "quoteId": "qte_3Cdz7KM4m1-X", "createdAt": "2026-07-19T12:36:03.626Z", "priceAsset": "HBAR", "buyerWallet": "0.0.88002", "completedAt": "2026-07-19T12:36:03.697Z", "platformFee": 0.01, "totalAmount": 0.51, "buyerAgentId": "agt__26SesUyoZ89", "sellerAgentId": "agt_QZheB9KzI5ax"}	failed	2026-07-19 12:36:03.626+00
ord_ffhk9Wgkm8-a	{"id": "ord_ffhk9Wgkm8-a", "result": {"ts": "2026-07-19T12:35:48.418Z", "echo": {"hello": "openmarket"}}, "status": "completed", "offerId": "off_WAUl8_m2jUOg", "quoteId": "qte_Qs-T_7oEThtw", "createdAt": "2026-07-19T12:35:48.393Z", "latencyMs": 1, "priceAsset": "HBAR", "buyerWallet": "0.0.424242", "completedAt": "2026-07-19T12:35:48.418Z", "platformFee": 0.002, "totalAmount": 0.102, "buyerAgentId": "agt_kauOLmcU1tkI", "sellerAgentId": "agt_QZheB9KzI5ax"}	completed	2026-07-19 12:35:48.393+00
ord_NPdObqlkf1k5	{"id": "ord_NPdObqlkf1k5", "error": "Security: devFakePay in production requires DEV_FAKE_PAYMENT_CONFIRMED=yes_i_know_what_i_am_doing env var", "status": "failed", "offerId": "off_WAUl8_m2jUOg", "quoteId": "qte_TORNXp2cpKna", "createdAt": "2026-07-19T12:03:34.513Z", "priceAsset": "HBAR", "buyerWallet": "0.0.424242", "platformFee": 0.002, "totalAmount": 0.102, "buyerAgentId": "agt_vNL-jwwVoboR", "sellerAgentId": "agt_QZheB9KzI5ax"}	failed	2026-07-19 12:03:34.513+00
ord_Xf5q2lm4Mzuk	{"id": "ord_Xf5q2lm4Mzuk", "result": {"ok": true, "input": {"text": "Hello World, this is a test of the OpenMarket marketplace.", "targetLang": "hy"}, "message": "Inline fulfill stub — connect seller webhook for real work", "llmError": "The operation was aborted due to timeout", "capability": "text.translate"}, "status": "completed", "offerId": "off_ixsa2_uk-dQT", "quoteId": "qte_34WeQZ0Gi-Cn", "createdAt": "2026-07-19T17:38:36.877Z", "latencyMs": 90007, "priceAsset": "HBAR", "buyerWallet": "0.0.777777", "completedAt": "2026-07-19T17:40:06.885Z", "platformFee": 0.0002, "totalAmount": 0.0102, "buyerAgentId": "agt_RDKhtKB3HEIq", "sellerAgentId": "agt_seed_translator"}	completed	2026-07-19 17:38:36.877+00
ord_iGY0Jk0OM0y0	{"id": "ord_iGY0Jk0OM0y0", "result": {"ts": "2026-07-19T16:46:21.212Z", "echo": {"hello": "python test"}}, "status": "completed", "offerId": "off_WAUl8_m2jUOg", "quoteId": "qte__tlpgg8Xcg7y", "createdAt": "2026-07-19T16:46:21.212Z", "latencyMs": 0, "priceAsset": "HBAR", "buyerWallet": "0.0.888888", "completedAt": "2026-07-19T16:46:21.212Z", "platformFee": 0.002, "totalAmount": 0.102, "buyerAgentId": "agt_NjWnvkTZ7jn0", "sellerAgentId": "agt_QZheB9KzI5ax"}	completed	2026-07-19 16:46:21.212+00
ord_mB82RPlpO7Wz	{"id": "ord_mB82RPlpO7Wz", "result": {"ts": "2026-07-19T16:41:47.034Z", "echo": {"hello": "sdk test"}}, "status": "completed", "offerId": "off_WAUl8_m2jUOg", "quoteId": "qte_ui84dkv6ap1J", "createdAt": "2026-07-19T16:41:47.034Z", "latencyMs": 0, "priceAsset": "HBAR", "buyerWallet": "0.0.999999", "completedAt": "2026-07-19T16:41:47.034Z", "platformFee": 0.002, "totalAmount": 0.102, "buyerAgentId": "agt__Db9flq95_3-", "sellerAgentId": "agt_QZheB9KzI5ax"}	completed	2026-07-19 16:41:47.034+00
ord_2IxILzvG1Sct	{"id": "ord_2IxILzvG1Sct", "result": {"ts": "2026-07-19T13:11:10.641Z", "echo": {"hello": "openmarket"}}, "status": "completed", "offerId": "off_WAUl8_m2jUOg", "quoteId": "qte_QDiy72xFi5ON", "createdAt": "2026-07-19T13:11:10.618Z", "latencyMs": 1, "priceAsset": "HBAR", "buyerWallet": "0.0.424242", "completedAt": "2026-07-19T13:11:10.641Z", "platformFee": 0.002, "totalAmount": 0.102, "buyerAgentId": "agt_-5YnIrfvTUsu", "sellerAgentId": "agt_QZheB9KzI5ax"}	completed	2026-07-19 13:11:10.618+00
ord_nO1mA04bqaVk	{"id": "ord_nO1mA04bqaVk", "result": {"ts": "2026-07-19T19:28:45.708Z", "echo": {"hello": "openmarket"}}, "status": "completed", "offerId": "off_WAUl8_m2jUOg", "quoteId": "qte_ekbql8SRQth5", "createdAt": "2026-07-19T19:28:45.692Z", "latencyMs": 1, "priceAsset": "HBAR", "buyerWallet": "0.0.424242", "completedAt": "2026-07-19T19:28:45.708Z", "platformFee": 0.002, "totalAmount": 0.102, "buyerAgentId": "agt_4P82IeMGiqWT", "sellerAgentId": "agt_QZheB9KzI5ax"}	completed	2026-07-19 19:28:45.692+00
ord_WoaUq8yGGE2h	{"id": "ord_WoaUq8yGGE2h", "result": {"ts": "2026-07-19T17:46:29.634Z", "echo": {"hello": "openmarket"}}, "status": "completed", "offerId": "off_WAUl8_m2jUOg", "quoteId": "qte_TgPIUQCAKxB4", "createdAt": "2026-07-19T17:46:29.615Z", "latencyMs": 0, "priceAsset": "HBAR", "buyerWallet": "0.0.424242", "completedAt": "2026-07-19T17:46:29.634Z", "platformFee": 0.002, "totalAmount": 0.102, "buyerAgentId": "agt_39aSJXHGi4DT", "sellerAgentId": "agt_QZheB9KzI5ax"}	completed	2026-07-19 17:46:29.615+00
ord_jS8d1OIEJxiH	{"id": "ord_jS8d1OIEJxiH", "result": {"ok": true, "input": {"text": "Hello World", "targetLang": "hy"}, "message": "Inline fulfill stub — connect seller webhook for real work", "llmError": "The operation was aborted due to timeout", "capability": "text.translate"}, "status": "completed", "offerId": "off_ixsa2_uk-dQT", "quoteId": "qte_ZheqRw96w8Lw", "createdAt": "2026-07-19T17:43:05.190Z", "latencyMs": 90001, "priceAsset": "HBAR", "buyerWallet": "0.0.666666", "completedAt": "2026-07-19T17:44:35.192Z", "platformFee": 0.0002, "totalAmount": 0.0102, "buyerAgentId": "agt_zklU_aB3WuqZ", "sellerAgentId": "agt_seed_translator"}	completed	2026-07-19 17:43:05.19+00
ord_HoUko4uhgSXl	{"id": "ord_HoUko4uhgSXl", "result": {"ok": true, "input": {"text": "USDC hello"}, "message": "Inline fulfill stub — connect seller webhook for real work", "capability": "demo.usdc"}, "status": "completed", "offerId": "off_hn2pYVAslPeF", "quoteId": "qte_5pUslOaU2Ogp", "createdAt": "2026-07-22T06:21:05.087Z", "latencyMs": 1, "priceAsset": "USDC", "buyerWallet": "0.0.9681969", "completedAt": "2026-07-22T06:21:14.338Z", "platformFee": 0.001, "totalAmount": 0.051, "buyerAgentId": "agt_2hnHr8HwRNFk", "sellerAgentId": "agt_NII8ICKE3fqm", "transactionId": "0.0.9681969@1784701261.716576866"}	completed	2026-07-22 06:21:05.087+00
ord_bRbJL3HflhI3	{"id": "ord_bRbJL3HflhI3", "error": "NO_CREDIT_TO_PAYEE", "result": {"ok": true, "input": {"text": "Hello World", "targetLang": "hy"}, "message": "Inline fulfill stub — connect seller webhook for real work", "llmError": "The operation was aborted due to timeout", "capability": "text.translate"}, "status": "completed", "offerId": "off_ixsa2_uk-dQT", "quoteId": "qte_2jIJmLx1yuAs", "createdAt": "2026-07-20T06:08:34.311Z", "latencyMs": 90005, "priceAsset": "HBAR", "buyerWallet": "0.0.9587214", "completedAt": "2026-07-20T06:31:07.502Z", "platformFee": 0.0002, "totalAmount": 0.0102, "buyerAgentId": "agt_-IVnogRNlw32", "sellerAgentId": "agt_seed_translator", "transactionId": "0.0.9651162@1784528699.733490733"}	completed	2026-07-20 06:08:34.311+00
ord_dEem1ogllGdI	{"id": "ord_dEem1ogllGdI", "error": "devFakePay is disabled - set ALLOW_DEV_FAKE_SETTLEMENT=true for local testing only", "status": "failed", "offerId": "off_h6-P0g_lLbKu", "quoteId": "qte_T8LHxBS3wn0R", "createdAt": "2026-07-20T05:59:41.304Z", "priceAsset": "HBAR", "buyerWallet": "0.0.8888002", "platformFee": 0.0004, "totalAmount": 0.0204, "buyerAgentId": "agt_bH_y5AtBdcN4", "sellerAgentId": "agt_qsFtn1FS__Wg"}	failed	2026-07-20 05:59:41.304+00
\.


--
-- Data for Name: quotes; Type: TABLE DATA; Schema: public; Owner: openmarket
--

COPY public.quotes (id, payload, expires_at, created_at) FROM stdin;
qte_QDiy72xFi5ON	{"id": "qte_QDiy72xFi5ON", "input": {"hello": "openmarket"}, "payTo": "0.0.1000", "agentId": "agt_QZheB9KzI5ax", "offerId": "off_WAUl8_m2jUOg", "createdAt": "2026-07-19T13:11:10.603Z", "expiresAt": "2026-07-19T13:21:10.603Z", "priceAsset": "HBAR", "buyerWallet": "0.0.424242", "platformFee": 0.002, "priceAmount": 0.1, "totalAmount": 0.102, "buyerAgentId": "agt_-5YnIrfvTUsu"}	2026-07-19 13:21:10.603+00	2026-07-19 13:11:10.603+00
qte_TORNXp2cpKna	{"id": "qte_TORNXp2cpKna", "input": {"hello": "openmarket"}, "payTo": "0.0.1000", "agentId": "agt_QZheB9KzI5ax", "offerId": "off_WAUl8_m2jUOg", "createdAt": "2026-07-19T12:03:34.496Z", "expiresAt": "2026-07-19T12:13:34.496Z", "priceAsset": "HBAR", "buyerWallet": "0.0.424242", "platformFee": 0.002, "priceAmount": 0.1, "totalAmount": 0.102, "buyerAgentId": "agt_vNL-jwwVoboR"}	2026-07-19 12:13:34.496+00	2026-07-19 12:03:34.496+00
qte_ekbql8SRQth5	{"id": "qte_ekbql8SRQth5", "input": {"hello": "openmarket"}, "payTo": "0.0.1000", "agentId": "agt_QZheB9KzI5ax", "offerId": "off_WAUl8_m2jUOg", "createdAt": "2026-07-19T19:28:45.675Z", "expiresAt": "2026-07-19T19:38:45.675Z", "priceAsset": "HBAR", "buyerWallet": "0.0.424242", "platformFee": 0.002, "priceAmount": 0.1, "totalAmount": 0.102, "buyerAgentId": "agt_4P82IeMGiqWT"}	2026-07-19 19:38:45.675+00	2026-07-19 19:28:45.675+00
qte_ZheqRw96w8Lw	{"id": "qte_ZheqRw96w8Lw", "input": {"text": "Hello World", "targetLang": "hy"}, "payTo": "0.0.1000", "agentId": "agt_seed_translator", "offerId": "off_ixsa2_uk-dQT", "createdAt": "2026-07-19T17:43:05.190Z", "expiresAt": "2026-07-19T17:53:05.190Z", "priceAsset": "HBAR", "buyerWallet": "0.0.666666", "platformFee": 0.0002, "priceAmount": 0.01, "totalAmount": 0.0102, "buyerAgentId": "agt_zklU_aB3WuqZ"}	2026-07-19 17:53:05.19+00	2026-07-19 17:43:05.19+00
qte_TgPIUQCAKxB4	{"id": "qte_TgPIUQCAKxB4", "input": {"hello": "openmarket"}, "payTo": "0.0.1000", "agentId": "agt_QZheB9KzI5ax", "offerId": "off_WAUl8_m2jUOg", "createdAt": "2026-07-19T17:46:29.601Z", "expiresAt": "2026-07-19T17:56:29.601Z", "priceAsset": "HBAR", "buyerWallet": "0.0.424242", "platformFee": 0.002, "priceAmount": 0.1, "totalAmount": 0.102, "buyerAgentId": "agt_39aSJXHGi4DT"}	2026-07-19 17:56:29.601+00	2026-07-19 17:46:29.601+00
qte_3Cdz7KM4m1-X	{"id": "qte_3Cdz7KM4m1-X", "payTo": "0.0.1000", "agentId": "agt_QZheB9KzI5ax", "offerId": "off_Dlxg5psmEn4x", "createdAt": "2026-07-19T12:36:03.626Z", "expiresAt": "2026-07-19T12:46:03.626Z", "priceAsset": "HBAR", "buyerWallet": "0.0.88002", "platformFee": 0.01, "priceAmount": 0.5, "totalAmount": 0.51, "buyerAgentId": "agt__26SesUyoZ89"}	2026-07-19 12:46:03.626+00	2026-07-19 12:36:03.626+00
qte_5pUslOaU2Ogp	{"id": "qte_5pUslOaU2Ogp", "input": {"text": "USDC hello"}, "payTo": "0.0.9587214", "agentId": "agt_NII8ICKE3fqm", "offerId": "off_hn2pYVAslPeF", "createdAt": "2026-07-22T06:21:05.066Z", "expiresAt": "2026-07-22T06:31:05.065Z", "priceAsset": "USDC", "buyerWallet": "0.0.9681969", "platformFee": 0.001, "priceAmount": 0.05, "totalAmount": 0.051, "buyerAgentId": "agt_2hnHr8HwRNFk"}	2026-07-22 06:31:05.065+00	2026-07-22 06:21:05.066+00
qte_2jIJmLx1yuAs	{"id": "qte_2jIJmLx1yuAs", "input": {"text": "Hello World", "targetLang": "hy"}, "payTo": "0.0.9587214", "agentId": "agt_seed_translator", "offerId": "off_ixsa2_uk-dQT", "createdAt": "2026-07-20T06:08:34.310Z", "expiresAt": "2026-07-20T06:18:34.310Z", "priceAsset": "HBAR", "buyerWallet": "0.0.9587214", "platformFee": 0.0002, "priceAmount": 0.01, "totalAmount": 0.0102, "buyerAgentId": "agt_-IVnogRNlw32"}	2026-07-20 06:18:34.31+00	2026-07-20 06:08:34.31+00
qte_T8LHxBS3wn0R	{"id": "qte_T8LHxBS3wn0R", "input": {"text": "Barev Dzayz, OpenMarket.ai-um barc'voum em ajs artadjakoujyouny. Sireli e heritage.", "targetLang": "en"}, "payTo": "0.0.9587214", "agentId": "agt_qsFtn1FS__Wg", "offerId": "off_h6-P0g_lLbKu", "createdAt": "2026-07-20T05:59:41.304Z", "expiresAt": "2026-07-20T06:09:41.304Z", "priceAsset": "HBAR", "buyerWallet": "0.0.8888002", "platformFee": 0.0004, "priceAmount": 0.02, "totalAmount": 0.0204, "buyerAgentId": "agt_bH_y5AtBdcN4"}	2026-07-20 06:09:41.304+00	2026-07-20 05:59:41.304+00
qte_34WeQZ0Gi-Cn	{"id": "qte_34WeQZ0Gi-Cn", "input": {"text": "Hello World, this is a test of the OpenMarket marketplace.", "targetLang": "hy"}, "payTo": "0.0.1000", "agentId": "agt_seed_translator", "offerId": "off_ixsa2_uk-dQT", "createdAt": "2026-07-19T17:38:36.877Z", "expiresAt": "2026-07-19T17:48:36.877Z", "priceAsset": "HBAR", "buyerWallet": "0.0.777777", "platformFee": 0.0002, "priceAmount": 0.01, "totalAmount": 0.0102, "buyerAgentId": "agt_RDKhtKB3HEIq"}	2026-07-19 17:48:36.877+00	2026-07-19 17:38:36.877+00
qte__tlpgg8Xcg7y	{"id": "qte__tlpgg8Xcg7y", "input": {"hello": "python test"}, "payTo": "0.0.1000", "agentId": "agt_QZheB9KzI5ax", "offerId": "off_WAUl8_m2jUOg", "createdAt": "2026-07-19T16:46:21.212Z", "expiresAt": "2026-07-19T16:56:21.212Z", "priceAsset": "HBAR", "buyerWallet": "0.0.888888", "platformFee": 0.002, "priceAmount": 0.1, "totalAmount": 0.102, "buyerAgentId": "agt_NjWnvkTZ7jn0"}	2026-07-19 16:56:21.212+00	2026-07-19 16:46:21.212+00
qte_ui84dkv6ap1J	{"id": "qte_ui84dkv6ap1J", "input": {"hello": "sdk test"}, "payTo": "0.0.1000", "agentId": "agt_QZheB9KzI5ax", "offerId": "off_WAUl8_m2jUOg", "createdAt": "2026-07-19T16:41:47.034Z", "expiresAt": "2026-07-19T16:51:47.034Z", "priceAsset": "HBAR", "buyerWallet": "0.0.999999", "platformFee": 0.002, "priceAmount": 0.1, "totalAmount": 0.102, "buyerAgentId": "agt__Db9flq95_3-"}	2026-07-19 16:51:47.034+00	2026-07-19 16:41:47.034+00
qte_Qs-T_7oEThtw	{"id": "qte_Qs-T_7oEThtw", "input": {"hello": "openmarket"}, "payTo": "0.0.1000", "agentId": "agt_QZheB9KzI5ax", "offerId": "off_WAUl8_m2jUOg", "createdAt": "2026-07-19T12:35:48.377Z", "expiresAt": "2026-07-19T12:45:48.377Z", "priceAsset": "HBAR", "buyerWallet": "0.0.424242", "platformFee": 0.002, "priceAmount": 0.1, "totalAmount": 0.102, "buyerAgentId": "agt_kauOLmcU1tkI"}	2026-07-19 12:45:48.377+00	2026-07-19 12:35:48.377+00
\.


--
-- Data for Name: used_tx; Type: TABLE DATA; Schema: public; Owner: openmarket
--

COPY public.used_tx (transaction_id, used_at) FROM stdin;
0.0.9651162@1784528699.733490733	2026-07-20 06:29:37.62409+00
0.0.9651162-1784528699-733490733	2026-07-20 06:29:37.627436+00
0.0.9681969@1784701261.716576866	2026-07-22 06:21:14.51084+00
0.0.9681969-1784701261-716576866	2026-07-22 06:21:14.512002+00
\.


--
-- Name: agents agents_api_key_key; Type: CONSTRAINT; Schema: public; Owner: openmarket
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_api_key_key UNIQUE (api_key);


--
-- Name: agents agents_pkey; Type: CONSTRAINT; Schema: public; Owner: openmarket
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_pkey PRIMARY KEY (id);


--
-- Name: audit_events audit_events_pkey; Type: CONSTRAINT; Schema: public; Owner: openmarket
--

ALTER TABLE ONLY public.audit_events
    ADD CONSTRAINT audit_events_pkey PRIMARY KEY (id);


--
-- Name: escrows escrows_pkey; Type: CONSTRAINT; Schema: public; Owner: openmarket
--

ALTER TABLE ONLY public.escrows
    ADD CONSTRAINT escrows_pkey PRIMARY KEY (id);


--
-- Name: offers offers_pkey; Type: CONSTRAINT; Schema: public; Owner: openmarket
--

ALTER TABLE ONLY public.offers
    ADD CONSTRAINT offers_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: openmarket
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: quotes quotes_pkey; Type: CONSTRAINT; Schema: public; Owner: openmarket
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT quotes_pkey PRIMARY KEY (id);


--
-- Name: used_tx used_tx_pkey; Type: CONSTRAINT; Schema: public; Owner: openmarket
--

ALTER TABLE ONLY public.used_tx
    ADD CONSTRAINT used_tx_pkey PRIMARY KEY (transaction_id);


--
-- Name: audit_at_idx; Type: INDEX; Schema: public; Owner: openmarket
--

CREATE INDEX audit_at_idx ON public.audit_events USING btree (at DESC);


--
-- Name: escrows_order_idx; Type: INDEX; Schema: public; Owner: openmarket
--

CREATE INDEX escrows_order_idx ON public.escrows USING btree (order_id);


--
-- Name: offers_agent_idx; Type: INDEX; Schema: public; Owner: openmarket
--

CREATE INDEX offers_agent_idx ON public.offers USING btree (agent_id);


--
-- Name: offers_capability_idx; Type: INDEX; Schema: public; Owner: openmarket
--

CREATE INDEX offers_capability_idx ON public.offers USING btree (capability) WHERE active;


--
-- Name: orders_status_idx; Type: INDEX; Schema: public; Owner: openmarket
--

CREATE INDEX orders_status_idx ON public.orders USING btree (status);


--
-- Name: offers offers_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: openmarket
--

ALTER TABLE ONLY public.offers
    ADD CONSTRAINT offers_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- PostgreSQL database dump complete
--

\unrestrict 43X5FTieA7CtoYtr0sR2YYuq848eezcV4mgYGtqefmxJZGGzA0HruMW0scdpx4g

